import React from "react";
import B from "./B";

function A() {
  return (
    <div>
      <h1>A Component</h1>
      <B />
    </div>
  );
}

export default A;
