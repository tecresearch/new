import React from "react";

const Profile = () => {
  return (
    <div className="w-40 mr-75">
      <div className="card pa-50">
        <h1>User Profile</h1>
        <form>
          <div className="layout-column mb-15">
            {/* <label htmlFor="firstname" className="mb-3">
              First Name
            </label>
            <input
              type="text"
              id="firstName"
              placeholder="Enter First Name"
              data-testid="firstNameInput"
            /> */}
            <div className="card pa-8" data-testid="firstNameDiv">
              Sherlock
            </div>
          </div>
          <div className="layout-column mb-15">
            <label htmlFor="lastname" className="mb-3">
              Last Name
            </label>
            <input
              type="text"
              id="lastName"
              placeholder="Enter Last Name"
              data-testid="lastNameInput"
            />
            <div className="card pa-8" data-testid="lastNameDiv"></div>
          </div>
          <div className="layout-column mb-30">
            <label htmlFor="email" className="mb-3">
              Email
            </label>
            <input
              type="text"
              id="email"
              placeholder="Enter Email"
              data-testid="emailInput"
            />
            <div className="card pa-8" data-testid="emailDiv"></div>
          </div>
          <div className="layout-row justify-content-end">
            <button type="submit" className="mx-0" data-testid="changeButton">
              Change Me
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Profile;
