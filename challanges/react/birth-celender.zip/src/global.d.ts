declare module 'h8k-components';
declare namespace JSX {
    interface IntrinsicElements {
      "h8k-navbar": {
        header: string;
      };
    }
  }