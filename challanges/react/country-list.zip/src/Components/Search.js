import React from 'react'

function Search() {
    return (
      <input data-testid="filterInput" className="large" placeholder="Enter Country Name"/>
  	);
}

export default Search;
