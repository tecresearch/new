import React from "react";

const MovieCard = () => {
  return (
    // set all data-testids according to the movie id.
    // Ex: on the movie card the data-testid for movie with id:1  will be movie-card-1
    <div className="movie-card" data-testid={`movie-card-0`}>
      <h3 data-testid={`movie-title-0`}>{`Inception`}</h3>
      <button className="danger" data-testid={`remove-btn-0`}>
        Remove
      </button>
      <button data-testid={`add-btn-0`}>
        {/* "Added" */}
        Add to Watchlist
      </button>
    </div>
  );
};

export default MovieCard;
