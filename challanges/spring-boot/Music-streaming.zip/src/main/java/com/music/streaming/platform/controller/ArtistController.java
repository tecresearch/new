package com.music.streaming.platform.controller;

public class ArtistController {
}
