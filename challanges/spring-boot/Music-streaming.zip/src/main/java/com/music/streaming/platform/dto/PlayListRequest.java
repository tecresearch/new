package com.music.streaming.platform.dto;

public record PlayListRequest(String name,
                              String description) {
}
