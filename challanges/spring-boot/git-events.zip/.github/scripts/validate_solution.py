if __name__ == "__main__":
    from validate import main
    main(True)
